﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinAutoEasyUI
{
    public interface IHelper
    {
        void ReleaseFile(TempModel tempModel);
    }
}
